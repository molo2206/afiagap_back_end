<?php

namespace App\Http\Controllers;

use App\Mail\contac_customs;
use App\Mail\Contact;
use App\Mail\Createcount;
use App\Models\ModelImagesPost;
use App\Models\PublicationsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class PublicationsController extends Controller
{
    public function addpublication(Request $request)
    {
        $request->validate([
            "image" => "required|image",
            "title" => "required",
            "content" => "required",
            "auteur" => "required",
            "image" => "required",
        ]);

        $image = UtilController::uploadImageUrl($request->image, '/uploads/publications/');
        $dataimage=PublicationsModel::create([
            "image" => $image,
            "title" => $request->title,
            "content" => $request->content,
            "auteur" => $request->auteur,
            "legend" => $request->legend,
        ]);
        $images = UtilController::uploadMultipleImage($request->images, '/uploads/alert/');
        foreach ($images as $item) {
            $dataimage->imagespublication()->attach([$dataimage->id =>
            [
                'name' => $item,
            ]]);
        }

        return response()->json([
            "message" => 'Liste des publications',
            "data" => PublicationsModel::with('images')->orderby('date_created', 'desc'),
            "code" => 200,
        ], 200);
    }
    public function getpublication()
    {
        return response()->json([
            "message" => 'Liste des publications',
            "data" => PublicationsModel::with('images')->get(),
            "code" => 200,
        ], 200);
    }

    public function detailpublication($id){
        return response()->json([
            "message" => 'Liste des publications',
            "data" => PublicationsModel::where('id', $id)->first(),
            "code" => 200,
        ], 200);
    }

    public function contact(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'phone' => 'required',
            'name' => 'required',
            'content' => 'required',
        ]);
        Mail::to($request->email)->send(new contac_customs(env('MAIL_FROM_ADDRESS')));
        Mail::to(env('MAIL_FROM_ADDRESS'))->send(new Contact($request->email, $request->name, $request->phone, $request->content));
        return response()->json([
            "message" => "Votre email à été envoyer avec succès.",
            "code" => 200,
        ], 200);
    }
}
