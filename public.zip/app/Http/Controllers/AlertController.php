<?php

namespace App\Http\Controllers;

use App\Models\airesante;
use App\Models\AlertModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class AlertController extends Controller
{
      public function sendAlert(Request $request)
      {
        $request->validate([
            'name_point_focal' => 'required',
            "phone" => 'required',
            "airid" => 'required',
            "date_notification" => 'required',
            "datealert" => 'required',
            "timealert" => 'required',
            "nbr_touche" => 'required',
            "dece_disponible" => 'required',
            "nbr_dece" => 'required',
            "animal_malade" => 'required',
            "animal_mort" => 'required',
            "evenement" => 'required',
            "mesure" => 'required',
            "maladieid" => 'required',
            "nb_animal_malade" => 'required',
            "nb_animal_mort" => 'required',
            "date_detection" => 'required',
            "time_detection"  => 'required'
            
        ]);
        $user= Auth::user();
        $aire = airesante::find($request->airid);
        if ($aire)
        {
            if($request->dece_disponible =="oui" || $request->dece_disponible =="non"){
                   if($request->animal_malade =="oui" || $request->animal_malade =="non"){
                       if($request->animal_mort =="oui" || $request->animal_mort =="non"){
                              if($request->evenement =="oui" || $request->evenement =="non"){
                                    $alert = AlertModel::create([
                                        'name_point_focal' => $request->name_point_focal,
                                        "phone" => $request->phone,
                                        "airid" => $request->airid,
                                        "date_notification" => $request->date_notification,
                                        "datealert" => $request->datealert,
                                        "timealert" => $request->timealert,
                                        "nbr_touche"=> $request->nbr_touche,
                                        "dece_disponible" => $request->dece_disponible,
                                        "nbr_dece" => $request->nbr_dece ,
                                        "animal_malade" => $request->animal_malade,
                                        "animal_mort" => $request->animal_mort,
                                        "evenement" => $request->evenement,
                                        "mesure" => $request->mesure,
                                        "maladieid" => $request->maladieid,
                                        "description" =>$request->description,
                                         "nb_animal_malade" =>$request->nb_animal_malade,
                                        "nb_animal_mort" =>$request->nb_animal_mort,
                                        "date_detection" =>$request->date_detection,
                                        "time_detection"  =>$request->time_detection,
                                        "userid" =>$user->id,
                                    ]);
                                    return response()->json([
                                        "message" => 'Alert envoyé avec succès!',
                                        "code" => 200
                                    ], 200);
                              }else{
                                return response()->json([
                                    "message" => "evemenent doit etre soit oui ou non !"
                                ], 402);
                              }
                       }else{
                        return response()->json([
                            "message" => "animal_mort doit etre soit oui ou non !"
                        ], 402);
                       }
                   }else{
                    return response()->json([
                        "message" => "animal_malade doit etre soit oui ou non !"
                    ], 402);
                   }
            }else{
                return response()->json([
                    "message" => "dece_disponible doit etre soit oui ou non !"
                ], 402);
            }
        } else {
            return response()->json([
                "message" => "aireid not found "
            ], 402);
        }
      }
      
       public function getAlert(){
         return response()->json([
            "message" => "Liste des alerts",
            "data" => AlertModel::with('dataaire','maladie')->get(),
        ], 200);
      }
      
      public function getDetailAlert($id){
           $alert= AlertModel::find($id);
           if($alert){
            return response()->json([
                "message" => "Detail de l'alert",
                "data" => AlertModel::with('dataaire','maladie')->where('id',$alert->id)->first(),
            ], 200);
           }else{
            return response()->json([
                "message" => "Identifiant not found",
                "code" => "402"
            ], 402);
           }
    }
     public function alertuser(){
        $user= Auth::user();
        if($user){
         return response()->json([
             "message" => "Liste des alerts par utilisateur",
             "data" => AlertModel::with('dataaire','maladie')->where('userid', $user->id)->get(),
         ], 200);
        }else{
         return response()->json([
             "message" => "Identifiant not found",
             "code" => "402"
         ], 402);
        }
    }
}
