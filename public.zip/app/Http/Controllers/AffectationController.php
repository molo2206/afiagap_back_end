<?php

namespace App\Http\Controllers;

use App\Models\AffectationModel;
use App\Models\AffectationPermission;
use App\Models\Organisation;
use App\Models\Permission;
use App\Models\RoleModel;
use App\Models\User;
use Illuminate\Http\Request;

class AffectationController extends Controller
{
 public function Affectation(Request $request)
    {
        $request->validate([
            'userid' => 'required',
        ]);
        $affectation = AffectationModel::where('userid', $request->userid)->first();
        if ($affectation) {
                if ($request->orgid == null) {
                    $affectation->orgid = $affectation->orgid;
                } else {
                    $affectation->orgid = $request->orgid;
                }
                if ($request->roleid == null) {
                    $affectation->roleid = $affectation->roleid;
                } else {
                    $affectation->roleid = $request->roleid;
                }
                    $affectation->orgid = $request->orgid;
                    $affectation->roleid = $request->roleid;
                    $affectation->userid = $request->userid;
                    $affectation->save();
                    return response()->json([
                        "message" => "Affctation réussie avec succèss",
                        "data" => AffectationModel::with('user', 'organisation', 'role')->where('userid',$request->userid)->first()
                    ], 200);
               
        } else {
            if (Organisation::where('id', $request->orgid)->first()) {

                if (RoleModel::where('id', $request->roleid)->first()) {

                    if (User::where('id', $request->userid)->first()) {
                        $aff = AffectationModel::create([
                            'orgid' => $request->orgid,
                            'roleid' => $request->roleid,
                            'userid' => $request->userid,
                        ]);
                        return response()->json([
                            "message" => "Affctation réussie avec succès",
                            "data" => AffectationModel::with('user', 'organisation', 'role')->where('userid',$request->userid)->first()
                        ], 200);
                    } else {
                        return response()->json([
                            "message" => "C'est utilisateur n'existe pas dans le système",
                        ], 422);
                    }
                } else {
                    return response()->json([
                        "message" => "C'est role n'existe pas dans le système "
                    ], 422);
                }
            } else {
                return response()->json([
                    "message" => "Cette organisation n'existe pas dans le système ",
                ], 422);
            }
        }
    }

    public function create_permission(Request $request){
           $request->validate([
                'name' => 'required',
                'psedo'=>'required',
           ]);

           if(Permission::where('name',$request->name)->exists()){
            return response()->json([
                "message" => "Cette permission existe déjà dans le système ",
            ], 422);
           }else{
              Permission::create([
                     'name' => $request->name,
                     'psedo' => $request->psedo,
           ]);
           return response()->json([
            "message" => "Création de la permission réussie avec succès"
           ], 200);
           }
    }

    public function update_permission(Request $request,$id){
        $request->validate([
            'name' => 'required',
            'psedo' => 'required',
        ]);
        $permission=Permission::find($id);
        if($permission){
            $permission->name=$request->name;
            $permission->psedo=$request->psedo;
            $permission->save();
            return response()->json([
                "message" => "La modification de la permission réussie"
            ], 200);
        }else{
            return response()->json([
                "message" => "Erreur de la modification permission",
            ], 422);
        }
    }

    public function list_permissions(){
            return response()->json([
                "message" => "Liste des permissions",
                "data" => Permission::all(),
            ], 200);
    }
    
    public function RetirerAcces(Request $request)
    {
      $request->validate([
             'idaffect_perm' => 'required',
       ]);

       foreach ($request->idaffect_perm as $item) {
        $affectationpermission=AffectationPermission::find($item);
        if($affectationpermission){
            $affectationpermission->deleted = 1;
            $affectationpermission->delete();
           
         }
       }
        return response()->json([
              "message" => "Permission rétirée avec succès",
          ], 200);
    }
    
    public function affecterPermission(Request $request)
    {
           $request->validate([
              'affectationid'=>'required',
              'permissionid'=>'required',
           ]);

           $affectation=AffectationModel::where('id', $request->affectationid)->first();
           $user=User::find($affectation->userid);
           if($affectation)
           {
             foreach ($request->permissionid as $item) {
             AffectationPermission::create([
                'affectationid'=>$request->affectationid,
                'permissionid' => $item,
             ]);
            }
             return response()->json([
                "message" => "Permission accordée",
               
            ], 200);
           }else{
            return response()->json([
                "message" => "Vous devez d'abord etre affecter",
            ], 422);
           }
    }

    public function List_PermissionsAccordees(Request $request){
           return response()->json([
                  "code" => "200",
                  "message" => "Liste des permissions",
                  "data" => AffectationPermission::with('permission')->get(),
           ],200);
    }
}
