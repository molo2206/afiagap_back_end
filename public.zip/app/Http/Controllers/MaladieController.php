<?php

namespace App\Http\Controllers;

use App\Models\Maladie;
use Illuminate\Http\Request;

class MaladieController extends Controller
{
    public function AddMaladie(Request $request)
    {
           $request->validate([
                    "name" => "required"
           ]);

           if(!Maladie::where('name', $request->name)->exists()){
            Maladie::create([
                "name" => $request->name,
            ]);
            return response()->json([
                "message" => 'Traitement réussi avec succès!',
                "code" => 200
            ], 200);
           }
    }

    public function updateMaladie(Request $request,$id)
    {
        $request->validate([
            'name' => 'required',
        ]);

        $maladie=Maladie::find($id);
        if($maladie){
            $maladie->name=$request->name;
            $maladie->save();
            return response()->json([
                "message" => "La modification réussie"
            ], 200);
        }else{
            return response()->json([
                "message" => "Erreur de la modification",
            ], 422);
        }
    }

    public function listMaladie(){

        $maladie = Maladie::all();
        return response()->json([
            "message" => "Listes des maladies!",
            "data" => $maladie,
            "code" => 200,
        ], 200);
           
    }

}
