<?php

namespace App\Http\Controllers;

use App\Models\RoleModel;
use Illuminate\Http\Request;

class RoleController extends Controller
{

    public function create(Request $request)
    {
        $request->validate([
            'name' => 'required',
        ]);
        if (!RoleModel::where('name', $request->name)->exists()) {
            $role = RoleModel::create([
                "name" => $request->name,
            ]);
            return response()->json([
                "message" => "Création du role réussie"
            ], 200);
        } else {
            return response()->json([
                "message" => "Cette informationexiste déjà dans le système : " . $request->name,
            ], 422);
        }
    }

    public function update(Request $request,$id){
        $request->validate([
            'name' => 'required',
        ]);
        $role=RoleModel::find($id);
        if($role){
            $role->name=$request->name;
            $role->save();
            return response()->json([
                "message" => "La modification du role réussie"
            ], 200);
        }else{
            return response()->json([
                "message" => "Erreur de la modification du role",
            ], 422);
        }
    }

    public function list_roles()
    {
        $allprovince = RoleModel::all();
        return response()->json([
            "message" => "Liste des roles!",
            "data" => $allprovince,
            "code" => 200,
        ], 200);
    }
}
