<?php

namespace App\Http\Controllers;

use App\Models\TypeCrise;
use Illuminate\Http\Request;

class CriseController extends Controller
{
     public function AddCrise(Request $request){
            $request->validate([
                    'name' => 'required',
            ]);

            TypeCrise::create([
                   'name' => $request->name,
            ]);

            return response()->json([
                "message" => 'Traitement réussi avec succès!',
                "code" => 200
            ], 200);


     }

     public function UpdateCrise(Request $request,$id)
     {
        $request->validate([
            'name' => 'required',
        ]);

        $type=TypeCrise::find($id);
        if($type){
            $type->name=$request->name;
            $type->save();
            return response()->json([
                "message" => "La modification réussie"
            ], 200);
        }else{
            return response()->json([
                "message" => "Erreur de la modification",
            ], 422);
        }

     }

     public function ListeCrise(Request $request)
     {
        return response()->json([
               "message" => "Liste des crises",
               "code" => "200",
               "data" => TypeCrise::all(),
        ]);
     }
}
